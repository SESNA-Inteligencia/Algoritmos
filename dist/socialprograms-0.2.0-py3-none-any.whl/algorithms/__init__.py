from algorithms import socialprograms
